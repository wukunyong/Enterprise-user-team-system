package com.amayadream.webchat.dao;

import com.amayadream.webchat.pojo.Room;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * NAME   :  WebChat/com.amayadream.webchat.dao
 * TODO   :
 */
@Service(value = "roomDao")
public interface IRoomDao {
    List<Room> selectAll(@Param("offset") int offset, @Param("limit") int limit);

    Room selectRoomByRoomid(String roomid);

    Room selectCount();

    boolean insert(Room room);

    boolean update(Room room);

    boolean delete(String roomid);

	Room selectRoomByUserid(String userid);
}

