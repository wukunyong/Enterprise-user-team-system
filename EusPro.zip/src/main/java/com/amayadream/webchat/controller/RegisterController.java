package com.amayadream.webchat.controller;

import com.amayadream.webchat.pojo.User;
import com.amayadream.webchat.service.ILogService;
import com.amayadream.webchat.service.IUserService;
import com.amayadream.webchat.utils.CommonDate;
import com.amayadream.webchat.utils.LogUtil;
import com.amayadream.webchat.utils.RegisterUtil;
import com.amayadream.webchat.utils.NetUtil;
import com.amayadream.webchat.utils.WordDefined;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

@Controller
@RequestMapping(value = "/user")
public class RegisterController {
	@Resource
    private IUserService userService;

    @Resource
    private ILogService logService;
    
    @RequestMapping(value = "/register", method = RequestMethod.GET)  
    public String register(){  
          
        return "register";  
        }  
    
    @RequestMapping(value = "/register", method = RequestMethod.POST)
    public String register(String userid, String password, String repassword,String nickname, HttpSession session, RedirectAttributes attributes,
                        WordDefined defined, CommonDate date,RegisterUtil regUtil, LogUtil logUtil, NetUtil netUtil, HttpServletRequest request) {
        User user = userService.selectUserByUserid(userid);
        if(user == null) {
        	userService.insert(regUtil.setregister(userid, password, nickname, date.getTime24(),1));
            logService.insert(logUtil.setLog(userid, date.getTime24(), defined.LOG_TYPE_REGISTER, defined.LOG_DETAIL_USER_REGISTER, netUtil.getIpAddress(request)));
            attributes.addFlashAttribute("message", defined.REGISTER_SUCCESS);
            return "redirect:/user/login";
        }else
        if (user.getNickname().equals(nickname)) {
            attributes.addFlashAttribute("error", defined.REGISTER_NICKNAME_ERROR);
            return "redirect:/user/register";
            
        }else 
            if (user.getUserid().equals(userid)) {
                attributes.addFlashAttribute("error", defined.REGISTER_USERID_ERROR);
                return "redirect:/user/register";
            }  
		return "redirect:/user/login";
        }
}
