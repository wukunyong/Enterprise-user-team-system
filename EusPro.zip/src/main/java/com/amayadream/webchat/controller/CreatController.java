package com.amayadream.webchat.controller;

import com.amayadream.webchat.pojo.Room;
import com.amayadream.webchat.service.ILogService;
import com.amayadream.webchat.service.IRoomService;
import com.amayadream.webchat.utils.CommonDate;
import com.amayadream.webchat.utils.LogUtil;
import com.amayadream.webchat.utils.CreatUtil;
import com.amayadream.webchat.utils.NetUtil;
import com.amayadream.webchat.utils.WordDefined;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

@Controller
@RequestMapping(value = "/user")
public class CreatController  {
	@Resource private Room room;
	@Resource private IRoomService roomService;
	@Resource private ILogService logService;
    
    @RequestMapping(value = "/creatroom", method = RequestMethod.GET)  
    public String creatroom(){  
        return "creatroom";  
        }  
    
    @RequestMapping(value = "/creatroom", method = RequestMethod.POST)
    public String room(String roomid, String roomtype, String roomname,String roomnum,String roomintro, HttpSession session, RedirectAttributes attributes,
                        WordDefined defined, CommonDate date,CreatUtil creUtil, LogUtil logUtil, NetUtil netUtil, HttpServletRequest request) {
        Room room = roomService.selectRoomByRoomid(roomid);
        if(room == null) {
        	roomService.insert(creUtil.setroom(session.getAttribute("userid").toString(),roomid, roomtype,roomname, roomnum,roomintro,date.getTime24()));
            session.setAttribute("roomid",roomid);
            session.setAttribute("roomname",roomname);
        	attributes.addFlashAttribute("message", defined.CREAT_SUCCESS);
            return "redirect:/user/chat";
        }else
        if (room.getroomname().equals(roomname)) {
            attributes.addFlashAttribute("error", defined.CREAT_ROOMNAME_ERROR);
            return "redirect:/user/creatroom";
            
        }else 
            if (room.getroomid().equals(roomid)) {
                attributes.addFlashAttribute("error", defined.CREAT_ROOMID_ERROR);
                return "redirect:/user/creatroom";
            }  
		return "redirect:/user/chat";
        }
}