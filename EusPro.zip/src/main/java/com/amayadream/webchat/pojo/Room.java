package com.amayadream.webchat.pojo;

import org.springframework.stereotype.Repository;

/**
 * NAME   :  WebChat/com.amayadream.webchat.pojo
 * TODO   :
 */
@Repository(value = "room")
public class Room {
	private String userid;      //管理员id
    private String roomid;      //合作室id
    private String roomtype;      //合作室类型
    private String roomname;      //合作室名称
    private String roomnum;      //合作室人数
    private String roomintro;      //合作室简介
    private String roombro;      //合作室公告
    private String rfirsttime;      //合作室注册时间
    
    
    /**
     * getter&setter
     * @return
     */
    public String getuserid() {
        return userid;
    }
    public void setuserid(String userid) {
        this.userid = userid;
    }

    
    public String getroomid() {
        return roomid;
    }
    public void setroomid(String roomid) {
        this.roomid = roomid;
    }

    public String getroomtype() {
        return roomtype;
    }
    public void setroomtype(String roomtype) {
        this.roomtype = roomtype;
    }
 
    public String getroomname() {
        return roomname;
    }
    public void setroomname(String roomname) {
        this.roomname = roomname;
    }
       
    public String getroomnum() {
        return roomnum;
    }
    public void setroomnum(String roomnum) {
        this.roomnum = roomnum;
    }

    public String getroomintro() {
        return roomintro;
    }
    public void setroomintro(String roomintro) {
        this.roomintro = roomintro;
    }
    
    public String getroombro() {
        return roomintro;
    }
    public void setroombro(String roombro) {
        this.roombro = roombro;
    }
    
    public String getrfirsttime() {
        return rfirsttime;
    }
    public void setrfirsttime(String rfirsttime) {
        this.rfirsttime = rfirsttime;
    }
}
