package com.amayadream.webchat.serviceImpl;

import com.amayadream.webchat.dao.IRoomDao;
import com.amayadream.webchat.pojo.Room;
import com.amayadream.webchat.service.IRoomService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * NAME   :  WebChat/com.amayadream.webchat.serviceImpl
 * TODO   :
 */
@Service(value = "roomService")
public class CreatServiceImpl implements IRoomService {

    @Resource private IRoomDao roomDao;

    @Override
    public List<Room> selectAll(int page, int pageSize) {
        return roomDao.selectAll(page, pageSize);
    }

    @Override
    public Room selectRoomByRoomid(String roomid) {
        return roomDao.selectRoomByRoomid(roomid);
    }

    @Override
    public int selectCount(int pageSize) {
        int pageCount = Integer.parseInt(roomDao.selectCount().getroomid());
        return pageCount % pageSize == 0 ? pageCount/pageSize : pageCount/pageSize + 1;
    }

    @Override
    public boolean insert(Room room) {
        return roomDao.insert(room);
    }

    @Override
    public boolean update(Room room) {
        return roomDao.update(room);
    }

    @Override
    public boolean delete(String roomid) {
        return roomDao.delete(roomid);
    }

	@Override
	public Room selectRoomByUserid(String userid) {
		return roomDao.selectRoomByUserid(userid);
	}
}