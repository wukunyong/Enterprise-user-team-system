package com.amayadream.webchat.utils;

import com.amayadream.webchat.pojo.Room;

public class CreatUtil {
	 public Room setroom(String userid, String roomid, String roomtype, String roomname, String roomnum,String roomintro,String rfirsttime){
		Room room = new Room();
		room.setuserid(userid);
		room.setroomid(roomid);
		room.setroomtype(roomtype);
		room.setroomname(roomname);
		room.setroomnum(roomnum);
		room.setroomintro(roomintro);
		room.setroomintro(roomintro);
		room.setrfirsttime(rfirsttime);
        return room;
        }
}