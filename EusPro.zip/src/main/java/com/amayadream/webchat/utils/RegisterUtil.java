package com.amayadream.webchat.utils;

import com.amayadream.webchat.pojo.User;

public class RegisterUtil {
	 public User setregister(String userid, String password, String nickname, String firsttime,int status){
		User user = new User();
		user.setUserid(userid);
		user.setPassword(password);
		user.setNickname(nickname);
		user.setFirsttime(firsttime);
		user.setStatus(status);
        return user;
        }
}