package com.amayadream.webchat.service;

import java.util.List;

import com.amayadream.webchat.pojo.Room;

public interface IRoomService {
	List<Room> selectAll(int page, int pageSize);
    Room selectRoomByRoomid(String roomid);
    int selectCount(int pageSize);
    boolean insert(Room room);
    boolean update(Room room);
    boolean delete(String roomid);
	Room selectRoomByUserid(String userid);
}
